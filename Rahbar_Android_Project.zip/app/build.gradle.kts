plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ir.rahbar.mobile"
    compileSdk = 35
    defaultConfig {
        applicationId = "ir.rahbar.fleet"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }
    flavorDimensions += "app"
    productFlavors {
        create("fleet") {
            dimension = "app"
            applicationId = "ir.rahbar.fleet"
            resValue("string", "app_name", "راهبر ناوگان")
        }
        create("drivers") {
            dimension = "app"
            applicationId = "ir.rahbar.drivers"
            resValue("string", "app_name", "راهبر رانندگان")
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug { }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
