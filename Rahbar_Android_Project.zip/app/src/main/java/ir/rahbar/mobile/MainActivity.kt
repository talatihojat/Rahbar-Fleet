package ir.rahbar.mobile

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var rootContainer: android.widget.FrameLayout
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSaveBytes: ByteArray? = null
    private var pendingSaveName: String = "rahbar.rahbar"
    private val openFileRequest = 4101
    private val saveFileRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        rootContainer = android.widget.FrameLayout(this)
        rootContainer.addView(webView, android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT
        ))
        setContentView(rootContainer)
        configureWebView(webView)
        webView.addJavascriptInterface(AndroidFileBridge(), "AndroidFile")
        webView.addJavascriptInterface(AndroidPrintBridge(webView), "AndroidPrint")
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun configureWebView(view: WebView) {
        view.settings.javaScriptEnabled = true
        view.settings.domStorageEnabled = true
        view.settings.allowFileAccess = true
        view.settings.allowContentAccess = true
        view.settings.javaScriptCanOpenWindowsAutomatically = true
        view.settings.setSupportMultipleWindows(true)
        view.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) {
                super.onPageFinished(v, url)
                v?.evaluateJavascript(
                    "window.print=function(){if(window.AndroidPrint){AndroidPrint.printWorkSheet();}};",
                    null
                )
            }

            override fun shouldOverrideUrlLoading(v: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return uri.scheme != "file" && uri.scheme != "about" && uri.scheme != "data"
            }
        }
        view.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                        "application/json", "application/vnd.rahbar+json",
                        "text/plain", "application/octet-stream"
                    ))
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                }
                startActivityForResult(intent, openFileRequest)
                return true
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                val popup = WebView(this@MainActivity)
                configureWebView(popup)
                rootContainer.addView(popup, android.widget.FrameLayout.LayoutParams(
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                    android.widget.FrameLayout.LayoutParams.MATCH_PARENT
                ))
                popup.addJavascriptInterface(AndroidPrintBridge(popup), "AndroidPrint")
                popup.webChromeClient = object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView?) {
                        rootContainer.removeView(window)
                        window?.destroy()
                    }
                }
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }
        }
    }

    inner class AndroidFileBridge {
        @JavascriptInterface
        fun saveBase64(filename: String, dataUrl: String) {
            try {
                val encoded = dataUrl.substringAfter(",", "")
                if (encoded.isBlank()) throw IllegalArgumentException("empty data")
                pendingSaveBytes = Base64.decode(encoded, Base64.DEFAULT)
                pendingSaveName = filename.substringAfterLast('/').ifBlank { "rahbar.rahbar" }
                runOnUiThread {
                    val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = if (pendingSaveName.endsWith(".csv", true)) "text/csv"
                               else "application/vnd.rahbar+json"
                        putExtra(Intent.EXTRA_TITLE, pendingSaveName)
                    }
                    startActivityForResult(intent, saveFileRequest)
                }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this@MainActivity, "آماده‌سازی فایل ناموفق بود", Toast.LENGTH_LONG).show() }
            }
        }
    }

    inner class AndroidPrintBridge(private val target: WebView) {
        @JavascriptInterface
        fun printWorkSheet() {
            runOnUiThread { printWebView(target) }
        }
    }

    private fun printWebView(target: WebView) {
        val manager = getSystemService(PRINT_SERVICE) as PrintManager
        val adapter = target.createPrintDocumentAdapter("Rahbar")
        manager.print("راهبر", adapter, PrintAttributes.Builder().build())
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == openFileRequest) {
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null)
                arrayOf(data.data!!) else null
            fileChooserCallback?.onReceiveValue(result)
            fileChooserCallback = null
        } else if (requestCode == saveFileRequest) {
            if (resultCode == Activity.RESULT_OK && data?.data != null && pendingSaveBytes != null) {
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { it.write(pendingSaveBytes!!) }
                    Toast.makeText(this, "فایل ذخیره شد", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ذخیره فایل ناموفق بود", Toast.LENGTH_LONG).show()
                }
            }
            pendingSaveBytes = null
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
